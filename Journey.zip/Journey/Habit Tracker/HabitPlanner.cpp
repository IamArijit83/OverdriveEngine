//----------------------------------------------------------
// Project: Journey Planner and Tracker
// Phases 1, 2 & 3: Using Linked List, Stack, Queue, BST
// Beginner Friendly - No STL in core DSA implementations except std::vector for dynamic strings
//----------------------------------------------------------
#include <iostream>
#include <vector>
using namespace std;

//----------------------------------------------------------
// Phase 1: Linked List for Habit Storage
//----------------------------------------------------------
struct HabitNode {
    vector<char> name;
    HabitNode* next;
};

class HabitList {
private:
    HabitNode* head;

public:
    HabitList() { head = nullptr; }

    void addHabit(string habit) {
        HabitNode* newNode = new HabitNode();
        for (char c : habit) newNode->name.push_back(c);
        newNode->next = head;
        head = newNode;
        cout << "Habit added: " << habit << endl;
    }

    void displayHabits() {
        HabitNode* temp = head;
        cout << "Your Habits (Linked List):\n";
        while (temp != nullptr) {
            for (char c : temp->name) cout << c;
            cout << endl;
            temp = temp->next;
        }
    }
};

//----------------------------------------------------------
// Phase 1: Stack for Habit History (LIFO) - Linked List
//----------------------------------------------------------
struct StackNode {
    vector<char> name;
    StackNode* next;
};

class HabitStack {
private:
    StackNode* top;

public:
    HabitStack() { top = nullptr; }

    void push(string habit) {
        StackNode* newNode = new StackNode();
        for (char c : habit) newNode->name.push_back(c);
        newNode->next = top;
        top = newNode;
    }

    void pop() {
        if (top == nullptr) {
            cout << "Stack underflow\n";
            return;
        }
        cout << "Removed from history: ";
        for (char c : top->name) cout << c;
        cout << endl;
        StackNode* temp = top;
        top = top->next;
        delete temp;
    }

    void reverse() {
        StackNode* prev = nullptr;
        StackNode* curr = top;
        while (curr != nullptr) {
            StackNode* next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
        }
        top = prev;
        cout << "Stack reversed.\n";
    }

    void replace(string oldHabit, string newHabit) {
        StackNode* curr = top;
        bool found = false;
        while (curr != nullptr) {
            string current(curr->name.begin(), curr->name.end());
            if (current == oldHabit) {
                curr->name.clear();
                for (char c : newHabit) curr->name.push_back(c);
                found = true;
            }
            curr = curr->next;
        }
        if (found)
            cout << "Habit '" << oldHabit << "' replaced with '" << newHabit << "'.\n";
        else
            cout << "Habit '" << oldHabit << "' not found in stack.\n";
    }

    void display() {
        StackNode* curr = top;
        cout << "Habit History (Stack):\n";
        while (curr != nullptr) {
            for (char c : curr->name) cout << c;
            cout << endl;
            curr = curr->next;
        }
    }
};

//----------------------------------------------------------
// Phase 1: Queue for Today's Plan (FIFO) - Linked List
//----------------------------------------------------------
struct QueueNode {
    vector<char> name;
    QueueNode* next;
};

class HabitQueue {
private:
    QueueNode* front;
    QueueNode* rear;

public:
    HabitQueue() {
        front = rear = nullptr;
    }

    void enqueue(string habit) {
        QueueNode* newNode = new QueueNode();
        for (char c : habit) newNode->name.push_back(c);
        newNode->next = nullptr;
        if (rear == nullptr) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    void dequeue() {
        if (front == nullptr) {
            cout << "Queue empty\n";
            return;
        }
        cout << "Removed from today's plan: ";
        for (char c : front->name) cout << c;
        cout << endl;
        QueueNode* temp = front;
        front = front->next;
        if (front == nullptr) rear = nullptr;
        delete temp;
    }

    void display() {
        QueueNode* temp = front;
        cout << "Today's Plan (Queue):\n";
        while (temp != nullptr) {
            for (char c : temp->name) cout << c;
            cout << endl;
            temp = temp->next;
        }
    }
};

//----------------------------------------------------------
// Phase 2: Weekly Habit Tracker - 2D Array View
//----------------------------------------------------------
class WeeklyTracker {
private:
    bool table[7][10]; // 7 days, 10 habits max
    int numHabits;
    vector<char> habitNames[10];

public:
    WeeklyTracker(int h) {
        numHabits = h;
        for (int i = 0; i < 7; ++i)
            for (int j = 0; j < 10; ++j)
                table[i][j] = false;
    }

    void setHabitName(int index, string name) {
        for (char c : name) habitNames[index].push_back(c);
    }

    void mark(int day, int habitIndex) {
        if (day < 0 || day >= 7 || habitIndex < 0 || habitIndex >= numHabits) {
            cout << "Invalid day or habit index\n";
            return;
        }
        table[day][habitIndex] = true;
    }

    void display() {
        cout << "\nWeekly Habit Tracker (✔ = Done, ✘ = Missed):\n";
        cout << "Day ";
        for (int j = 0; j < numHabits; ++j) {
            cout << "| ";
            for (char c : habitNames[j]) cout << c;
            cout << " ";
        }
        cout << "\n------------------------------------------------------------\n";
        string days[7] = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        for (int i = 0; i < 7; ++i) {
            cout << days[i] << " ";
            for (int j = 0; j < numHabits; ++j) {
                cout << "|  " << (table[i][j] ? "✔" : "✘") << "   ";
            }
            cout << endl;
        }
    }
};

//----------------------------------------------------------
// Phase 3: BST for Completed Habits
//----------------------------------------------------------
struct BSTNode {
    vector<char> name;
    BSTNode* left;
    BSTNode* right;

    BSTNode(string h) {
        for (char c : h) name.push_back(c);
        left = right = nullptr;
    }
};

class HabitBST {
private:
    BSTNode* root;

    BSTNode* insert(BSTNode* node, string habit) {
        if (node == nullptr)
            return new BSTNode(habit);

        string current(node->name.begin(), node->name.end());
        if (habit < current)
            node->left = insert(node->left, habit);
        else if (habit > current)
            node->right = insert(node->right, habit);
        return node;
    }

    void inorder(BSTNode* node) {
        if (node != nullptr) {
            inorder(node->left);
            for (char c : node->name) cout << c;
            cout << " ";
            inorder(node->right);
        }
    }

public:
    HabitBST() { root = nullptr; }

    void markComplete(string habit) {
        root = insert(root, habit);
        cout << "Marked as completed: " << habit << endl;
    }

    void showCompleted() {
        cout << "Completed Habits (BST): ";
        inorder(root);
        cout << endl;
    }
};

//----------------------------------------------------------
// Main Function
//----------------------------------------------------------
int main() {
    HabitList habits;
    HabitStack history;
    HabitQueue today;

    int n;
    cout << "Enter number of habits to track (max 10): ";
    cin >> n;
    cin.ignore();

    WeeklyTracker tracker(n);

    for (int i = 0; i < n; ++i) {
        string h;
        cout << "Enter habit " << i + 1 << ": ";
        getline(cin, h);

        habits.addHabit(h);
        history.push(h);
        today.enqueue(h);
        tracker.setHabitName(i, h);
    }

    cout << endl;
    habits.displayHabits();
    history.display();
    history.reverse();
    history.display();

    string oldH, newH;
    cout << "\nEnter habit to replace in history: ";
    getline(cin, oldH);
    cout << "Enter new habit: ";
    getline(cin, newH);
    history.replace(oldH, newH);
    history.display();

    today.display();

    cout << "\nMark weekly habit completions (0 = Monday, 6 = Sunday):\n";
    int entries;
    cout << "How many records to enter? ";
    cin >> entries;
    for (int i = 0; i < entries; ++i) {
        int day, idx;
        cout << "Enter day (0-6): ";
        cin >> day;
        cout << "Enter habit index (0 to " << n - 1 << "): ";
        cin >> idx;
        tracker.mark(day, idx);
    }

    tracker.display();

    HabitBST completed;
    int m;
    cout << "\nHow many habits did you complete today? ";
    cin >> m;
    cin.ignore();

    for (int i = 0; i < m; ++i) {
        string ch;
        cout << "Enter completed habit: ";
        getline(cin, ch);
        completed.markComplete(ch);
    }

    completed.showCompleted();

    return 0;
}