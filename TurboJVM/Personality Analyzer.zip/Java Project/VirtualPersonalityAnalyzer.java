import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

// Enum to define personality types with description and image path
enum PersonalityType {
    INFJ("INFJ - The Advocate: Creative and insightful", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_3Jeheu3i3QZNgKJU.jpg"),
    ENTP("ENTP - The Debater: Smart and curious thinker", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\f638d900349b2c041fb221c37eb944b3.jpg"),
    INTJ("INTJ - The Architect: Strategic and logical", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_3hFK2qs7rltrstMa.jpg"),
    ENFP("ENFP - The Campaigner: Enthusiastic and free-spirited", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\c1c3d38c2bbda45db0c9904ced6d5919.jpg"),
    ISTJ("ISTJ - The Logistician: Practical and fact-minded", "0__A2Y8apXGC-v2tw5.jpg"),
    ISFP("ISFP - The Adventurer: Flexible and charming", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0__6T_g5X3a_lWyUVP.jpg"),
    ENTJ("ENTJ - The Commander: Bold and imaginative leader", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\1_bKw4TeVUjPMVQ5a9XY-3sA.png"),
    INFP("INFP - The Mediator: Idealistic and empathetic", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_NXmR3BL-W6rZjvxD.jpg"),
    ESFJ("ESFJ - The Consul: Social and popular", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_DmfMB5b6yhJ02x9b.jpg"),
    ESTP("ESTP - The Entrepreneur: Energetic and smart", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_f9JmFfOc8aAYRYJd.jpg"),
    ISTP("ISTP - The Virtuoso: Practical and experimental", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_7OIaLV1oFwvRFINi.jpg"),
    ESFP("ESFP - The Entertainer: Spontaneous and fun-loving", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_UWfmG2S40E1rET9D.jpg"),
    ISFJ("ISFJ - The Defender: Warm and dedicated", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_DVhX_mrbScgYtQNJ.jpg"),
    ESTJ("ESTJ - The Executive: Strong-willed and organized", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\0_i6oY4LAN-MQAJLEb.jpg"),
    INTX("INTX - The Thinker: Logical and independent", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\4cpzgu88soz51.jpg"),
    AMBIVERT("AMBIVERT - Balanced: A mix of introvert and extrovert", "C:\\Users\\ariji\\OneDrive\\Desktop\\Java Project\\5f472b54e4c4de695b3951e4ece11788.jpg");

    private final String description;
    private final String imagePath;

    PersonalityType(String description, String imagePath) {
        this.description = description;
        this.imagePath = imagePath;
    }

    public String getDescription() {
        return description;
    }

    public String getImagePath() {
        return imagePath;
    }
}

// Class representing a user
class User {
    private String name;
    private int age;
    private PersonalityType personality;

    public User(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public PersonalityType getPersonality() { return personality; }
    public void setPersonality(PersonalityType personality) {
        this.personality = personality;
    }
}

// GUI class for the personality analyzer
class PersonalityAnalyzerGUI extends JFrame implements ActionListener {
    private JTextField nameField, ageField;
    private JTextArea resultArea;
    private JButton analyzeButton;
    private JLabel imageLabel;

    public PersonalityAnalyzerGUI() {
        setTitle("🌟 Welcome to Virtual Personality Analyzer 🌟");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JTextArea personalityTypesArea = new JTextArea(10, 35);
        personalityTypesArea.setEditable(false);
        personalityTypesArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        StringBuilder personalities = new StringBuilder("Available Personality Types:\n");
        for (PersonalityType type : PersonalityType.values()) {
            personalities.append("• ").append(type.getDescription()).append("\n");
        }
        personalityTypesArea.setText(personalities.toString());
        add(new JScrollPane(personalityTypesArea));

        add(new JLabel("Enter your name:"));
        nameField = new JTextField(20);
        add(nameField);

        add(new JLabel("Enter your age:"));
        ageField = new JTextField(5);
        add(ageField);

        analyzeButton = new JButton("Analyze Personality");
        analyzeButton.addActionListener(this);
        add(analyzeButton);

        resultArea = new JTextArea(6, 35);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Arial", Font.BOLD, 13));
        add(new JScrollPane(resultArea));

        imageLabel = new JLabel();
        add(imageLabel);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                throw new IllegalArgumentException("Name cannot be empty.");
            }

            int age = Integer.parseInt(ageField.getText().trim());
            if (age <= 0) {
                throw new IllegalArgumentException("Age must be positive.");
            }

            User user = new User(name, age);
            PersonalityType result = VirtualPersonalityAnalyzer.analyzePersonality();
            user.setPersonality(result);

            resultArea.setText("✨ Hello, " + user.getName() + "!\n"
                    + "🧠 You are: " + user.getPersonality() + "\n"
                    + "💡 Fact: " + user.getPersonality().getDescription());

            ImageIcon icon = new ImageIcon(user.getPersonality().getImagePath());
            Image scaledImage = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));

        } catch (NumberFormatException ex) {
            resultArea.setText("⚠️ Please enter a valid numeric age.");
        } catch (IllegalArgumentException ex) {
            resultArea.setText("⚠️ " + ex.getMessage());
        } catch (Exception ex) {
            resultArea.setText("❌ An unexpected error occurred.");
        }
    }
}

// Main class
public class VirtualPersonalityAnalyzer {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PersonalityAnalyzerGUI().setVisible(true));
    }

    // Console-based analysis logic (still used by GUI)
    public static PersonalityType analyzePersonality() {
        int introvertScore = 0, extrovertScore = 0;
        int thinkingScore = 0, feelingScore = 0;
        int judgingScore = 0, perceivingScore = 0;

        System.out.println("\n[Console Questions] Answer with yes/no:");

        if (getResponse("Do you enjoy being alone?") == 1) introvertScore++;
        if (getResponse("Do you prefer deep conversations?") == 1) introvertScore++;
        if (getResponse("Do you feel energized after social interactions?") == 1) extrovertScore++;
        if (getResponse("Do you enjoy meeting new people?") == 1) extrovertScore++;
        if (getResponse("Do you rely more on logic than emotions?") == 1) thinkingScore++;
        if (getResponse("Do you often prioritize feelings over logic?") == 1) feelingScore++;
        if (getResponse("Do you prefer structured plans over spontaneity?") == 1) judgingScore++;
        if (getResponse("Do you prefer to go with the flow?") == 1) perceivingScore++;

        if (introvertScore > extrovertScore) {
            if (thinkingScore > feelingScore) {
                return judgingScore > perceivingScore ? PersonalityType.INTJ : PersonalityType.INTX;
            } else {
                return judgingScore > perceivingScore ? PersonalityType.INFJ : PersonalityType.INFP;
            }
        } else {
            if (thinkingScore > feelingScore) {
                return judgingScore > perceivingScore ? PersonalityType.ENTJ : PersonalityType.ENTP;
            } else {
                return judgingScore > perceivingScore ? PersonalityType.ESFJ : PersonalityType.ENFP;
            }
        }
    }

    // Simple yes/no input for console fallback
    private static int getResponse(String question) {
        System.out.print(question + " (yes/no): ");
        String response = scanner.nextLine().trim().toLowerCase();
        return response.equals("yes") ? 1 : 0;
    }
}
